﻿namespace My_Executer
{
    internal class fastColored
    {
    }
}